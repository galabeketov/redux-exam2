import * as React from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardContent from "@mui/material/CardContent";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";

export default function MyCard({ data }) {
  console.log(data);
  return (
    <Card sx={{ width: "100%", px: 1, py: 2 }}>
      <CardContent>
        <Typography sx={{ fontSize: 16, fontWeight: "bold" }} gutterBottom>
          <Box component={"img"} src="card.png" width={"25px"}></Box> Country:
          {data.country}
        </Typography>
        <Typography
          variant="h4"
          sx={{ fontSize: "40px", fontWeight: "bold", py: 4 }}
        >
          {data.name}
        </Typography>
        <Typography sx={{ fontSize: 16, fontWeight: "bold" }} gutterBottom>
          <Box
            component={"img"}
            src="domain.png"
            width={"25px"}
            sx={{ objectFit: "cover" }}
          ></Box>{" "}
          Country:
          {data.country}
        </Typography>
        <Typography variant="body2">
          well meaning and kindly.
          <br />
          {'"a benevolent smile"'}
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small">Learn More</Button>
      </CardActions>
    </Card>
  );
}
